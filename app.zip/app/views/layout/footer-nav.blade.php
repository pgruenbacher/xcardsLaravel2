<div class="footer container text-center">
	<h1>X-PRESS YOURSELF WITHOUT LIMITS</h1>
	<div class="row">
		<ul class="fa-ul inline-list">
			<li><a class="list-item" href="https://www.facebook.com/XPressCards"><i class="fa fa-2x fa-facebook"></i></a></li>
			<li><a class="list-item" href="http://instagram.com/xpresscards"><i class="fa fa-2x fa-instagram"></i></a></li>
			<li><a class="list-item" href="http://www.pinterest.com/XPressCards/"><i class="fa fa-2x fa-pinterest"></i></a></li>
			<li><a class="list-item" href="https://twitter.com/xpresscards"><i class="fa fa-2x fa-twitter"></i></a></li>
		</ul>
	</div>
	<div class="row">
		<ul class="inline-list">
			<li><a class="list-item" href="{{URL::route('build-index')}}">Build a Card</a></li>
			<li><a href="{{URL::route('fanpage')}}" class="list-item">Brutus Fans</a></li>
			<li><a href="{{URL::route('printing')}}" class="list-item">Printing Services</a></li>
			<li><a href="{{URL::route('buy-credits')}}" class="list-item">Buy Credits</a></li>
		</ul>
	</div>
	<div class="row">
		<ul class="inline-list">
			<li><a href="{{URL::route('company')}}" class="list-item">Company</a></li>
			<li><a href="{{URL::route('faq')}}" class="list-item">FAQ</a></li>
			<li><a href="{{URL::route('contact')}}" class="list-item">Contact Us</a></li>
			<li><a href="{{URL::route('privacy')}}" class="list-item">Privacy</a></li>
			<li><a href="{{URL::route('website-terms')}}" class="list-item">Terms of Use</a></li>
		</ul>
	</div>
</div>