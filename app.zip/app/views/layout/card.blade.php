<!doctype html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	@yield('header')
</head>
<body>
	@yield('card')	
<footer>
	@yield('footer')
</footer>
</body>
</html>