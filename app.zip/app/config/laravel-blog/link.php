<?php

/**
 * Configuration options for the link on an item
 */
return array(

	/**
	 * Determines whether the link fields are shown in the administrator screens and whether they are seeded in the
	 * fake seeder
	 */
	'show' => true,

);