<?php

return array(
	'api_key'=>'yJSXG2ygtB5IDmjF7AIiUw'
);
