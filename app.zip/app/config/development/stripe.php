<?php
//Sandbox Keys
return array(
	'secret_key'=>'sk_test_QLCwJNGWSKjOVqb4HEY1h359',
	'publishable_key'=>'pk_test_5cjIWWuGdWCAFftp2SLoyGwb'
);