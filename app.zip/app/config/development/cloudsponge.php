<?php

return array(
	'domain_key'=>'DD48P5NJKWBRV3YHF35U',
	'domain_password'=>'Q9qGfcOd2tJLpw97',
);
