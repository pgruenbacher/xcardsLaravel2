<?php
//Sandbox Keys
return array(
	'secret_ID'=>'e68b1315-3df2-4dfc-ae9a-822e4e36ae71',
	'secret_token'=>'8MJYSvHM20Dl08BMHuG%2BGVLMQFncqyUa8lQ%2Bcat7kCOpsyHdh3hCcDDcXo1YFasMwQMiiqsebjxK61EKk%2FWzJg%3D%3D',
	'publishable_key'=>'3445594376114437007',
	'mailer_id'=>'901410940',
	'barcode_id'=>'00',
	'service_id'=>'702',
);