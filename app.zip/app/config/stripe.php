<?php

return array(
	'secret_key'=>'sk_live_E70P9QyCjzilg2SpLhpjfUUB',
	'publishable_key'=>'pk_live_ki5jFqHgLrchivkhoXcfyFLH'
);
