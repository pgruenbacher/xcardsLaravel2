<?php

return array(
    'view' => 'partials.breadcrumbs',
);
