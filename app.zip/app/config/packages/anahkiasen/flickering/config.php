<?php return array(

	// API credentials
	//////////////////////////////////////////////////////////////////////

	'api_key'    => '641e676b8937a4f90e7e7dac967bef01 ',
	'api_secret' => 'e476950f49c9b65d',

	// Cache configuration
	//////////////////////////////////////////////////////////////////////

	'cache' => array(

		// Whether Flickering should cache requests or not
		'cache_requests' => true,

		// The lifetime of a cached request (minutes)
		'lifetime' => 60 * 24 * 365,
	),

);
