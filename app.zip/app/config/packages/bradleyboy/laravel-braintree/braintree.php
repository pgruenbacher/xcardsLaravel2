<?php

return array(
	'environment'             => 'sandbox',
	'merchantId'              => 'x7z9c36sphmx8955',
	'publicKey'               => 'jbjp8gh9g7x65jf5',
	'privateKey'              => 'a2d5f4de43b1417f97bd2c670ddcfd8d',
	'clientSideEncryptionKey' => 'MIIBCgKCAQEA584g7z5iO8pW30IqG1+U8E4B2gQ0VXDwmwRZ19P+QBUPTcGBA3Avsz9AwotZnjnCcaXxzwvTp1Rt272P3eKRPagMlLHWTaLJcVbutlna4GysITKcYis6Kzn/25vimnweN5JhYWdDnnBC0IVazfzF7Pfi4/DHBS2jFKE502nf3g5c9lnSODKzX8fn9xqcLAFz21re2uXOA3wOAzyvlXCGz/Bb6nNBUXeXfEzWa/AULXTlgzycnvRvh8XTumwE8461v8WbYoEpCGasSh8Zn42LZ1vDol9wIYVR7Fs0qeG//B2Lc+t+rMUnwzOUH1OQSwh3yXheZcdaxEzQfkB9Hn5eZQIDAQAB',
);