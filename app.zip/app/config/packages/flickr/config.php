<?php

return array(
	$flickrApiKey => '641e676b8937a4f90e7e7dac967bef01',
	$flickrApiSecret => 'e476950f49c9b65d',
);
