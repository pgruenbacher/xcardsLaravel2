<?php namespace XCards\Entities;

class Post extends \Eloquent{
	protected $presenter='XCards/Presenters/Post';
	
	
}
