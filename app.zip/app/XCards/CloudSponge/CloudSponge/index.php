<?php
header('Location: step_1_start.php') ;
?>