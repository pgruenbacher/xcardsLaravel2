<?php

// CloudSponge.com PHP Library v0.9 Beta
// http://www.cloudsponge.com
// Copyright (c) 2010 Cloud Copy, Inc.
// Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
//
// Written by Graeme Rouse
// graeme@cloudsponge.com

/* Global Configuration Settings */
// The simple inteface below defines contacts that identify your application to CloudSponge.com.
interface iCSConstants {
  // DOMAIN_KEY and DOMAIN_PASSWORD should contain your domain key and domain password for CloudSponge.com access.
 const DOMAIN_KEY = "CHANGEME";
 const DOMAIN_PASSWORD = "CHANGEME";
}
?>