<?php namespace XCards\CloudSponge;

interface CloudSpongeInterface{
	public function requestContacts($service, $username, $password){
		
	}
	public function importContacts($import_id) {
	}
}
